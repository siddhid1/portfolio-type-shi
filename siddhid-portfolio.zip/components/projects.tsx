'use client'

import { motion } from 'framer-motion'
import { ExternalLink, GitBranch } from 'lucide-react'

export function Projects() {
  const projects = [
    {
      name: 'Distributed Cache System',
      description: 'High-performance distributed caching layer built with Go and Redis, supporting millions of requests per second with sub-millisecond latency.',
      tech: ['Go', 'Redis', 'gRPC', 'PostgreSQL'],
      github: '#',
      demo: '#',
    },
    {
      name: 'Real-time Analytics Engine',
      description: 'Stream processing system for analyzing real-time data using Apache Kafka, showcasing event-driven architecture and scalable data pipelines.',
      tech: ['Node.js', 'Kafka', 'Elasticsearch', 'Grafana'],
      github: '#',
      demo: '#',
    },
    {
      name: 'Microservices Framework',
      description: 'Lightweight framework for building microservices with automatic service discovery, health checks, and load balancing built-in.',
      tech: ['Go', 'Docker', 'Kubernetes', 'gRPC'],
      github: '#',
      demo: '#',
    },
    {
      name: 'Database Query Optimizer',
      description: 'Advanced query optimization engine for PostgreSQL that analyzes and optimizes complex queries, reducing execution time by up to 80%.',
      tech: ['PostgreSQL', 'Python', 'Query Planning', 'System Design'],
      github: '#',
      demo: '#',
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 border-t border-border">
      <div className="max-w-4xl mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.h2 variants={itemVariants} className="text-3xl font-bold text-foreground mb-12 font-mono">
            Featured Projects
          </motion.h2>

          <div className="grid gap-6">
            {projects.map((project, index) => (
              <motion.div
                key={project.name}
                variants={itemVariants}
                whileHover={{ y: -3 }}
                className="group p-6 bg-card border border-border hover:border-primary transition-all duration-200"
              >
                <div className="flex flex-col gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground font-mono group-hover:text-primary transition-colors">
                      {project.name}
                    </h3>
                    <p className="text-sm text-secondary font-mono mt-2 leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="text-xs px-3 py-1 bg-background border border-border text-foreground rounded-full font-mono"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Links */}
                  <div className="flex gap-4 pt-2">
                    <a
                      href={project.github}
                      className="inline-flex items-center gap-2 text-xs font-mono text-secondary hover:text-primary transition-colors"
                    >
                      <GitBranch size={14} />
                      Code
                    </a>
                    {project.demo !== '#' && (
                      <a
                        href={project.demo}
                        className="inline-flex items-center gap-2 text-xs font-mono text-secondary hover:text-primary transition-colors"
                      >
                        <ExternalLink size={14} />
                        Demo
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.p variants={itemVariants} className="text-sm text-secondary font-mono mt-12 text-center">
            Want to see more?{' '}
            <a
              href="https://github.com/siddhid1"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              Check out my GitHub
            </a>
          </motion.p>
        </motion.div>
      </div>
    </section>
  )
}
